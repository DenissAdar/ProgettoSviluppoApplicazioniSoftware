package catering.businesslogic.task;

public class SheetException extends Exception{
}
