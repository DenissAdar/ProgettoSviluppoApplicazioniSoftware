package catering.businesslogic;

public class UseCaseLogicException extends Exception {
}
